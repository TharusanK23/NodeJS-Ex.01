var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("Songs");
  /*Delete the first customers with the address "Mountain 21":*/
  var myquery = {'Song Name': 'Roja Poonthottam'};
  dbo.collection("songdetails​").deleteOne(myquery, function(err, obj) {
    if (err) throw err;
    console.log("1 document deleted");
    db.close();
  });
});

/*
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("Songs");
  /*Delete all customers where the address starts with an "O":*/
 /* var myquery = {'Song Name': 'Roja Poonthottam'};
  dbo.collection("songdetails​").deleteMany(myquery, function(err, obj) {
    if (err) throw err;
    console.log(obj.result.n + " document(s) deleted");
    db.close();
  });
});
*/
