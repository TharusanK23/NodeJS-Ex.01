var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'ktharu0305@gmail.com',
    pass: 'kirisha01'
  }
});

var mailOptions = {
  from: 'ktharu0305@gmail.com',
  to: 'k.tharusan@gmail.com',
  subject: 'Testing my nodemailer module',
  text: 'This is easy !'
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
  }
});